<!-- vw_about.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <!-- Add your CSS styles or link to external stylesheets here -->
</head>

<body>
    <!-- Section -->
    <section class="py-5">
        <div class="container px-4 px-lg-5 mt-5">
            <div class="row">
                <div class="col-lg-8">
                    <h2 class="fw-bolder">About Our Company</h2>
                    <p>This is a brief description of your company or organization. You can provide information about your mission, vision, and values. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <!-- Add more content as needed -->
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <section class="py-5">
        <!-- Your footer content goes here -->
    </section>

    <!-- Add your JavaScript scripts or link to external scripts here -->
</body>

</html>
